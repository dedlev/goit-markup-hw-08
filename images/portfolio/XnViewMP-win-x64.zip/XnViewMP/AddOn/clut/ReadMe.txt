The Hald CLUT algorithm has been developed by Eskil Steenberg as described at http://www.quelsolaar.com/technology/clut.html
http://rawpedia.rawtherapee.com/Film_Simulation

Hald CLUT or RGB color lookup supported

You can check identity.zip for identity RGB LUT & Hald CLUT

This folder contains:

- RGB Lookup from InstaCam

- Technicolor 2 from script by elsamuko
  http://registry.gimp.org/node/9129
  http://registry.gimp.org/node/9256

- polaroid_px-680_warm_--, fuji_fp-100c_++_alt, vibrant_alien, Kodak Kodachrome 25
  http://gmic.eu/film_emulation/
  https://patdavid.net/2015/03/film-emulation-in-rawtherapee.html
  https://patdavid.net/2013/09/film-emulation-presets-in-gmic-gimp.html

- K-TONE Vintage Kodachrome
  https://frankglencairn.wordpress.com/2014/01/15/everything-looks-better-on-kodachrome-k-tone-lut/
